영원회귀: 블랙서바이벌의 아이템 도감입니다.

https://wani3327.github.io/erbsItem/
